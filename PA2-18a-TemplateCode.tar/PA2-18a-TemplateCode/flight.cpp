/*
  name
  section
  assignment
  file
*/

#include "flight.h"

Flight::Flight()
{

}

Flight::Flight(std::string fn, std::string dest, std::string dt, std::string gn)
{

}

Flight::~Flight()
{

}

bool compareToDestination(Flight f1, Flight f2)
{
  return false;
}

bool compareToDepartureTime(Flight f1, Flight f2)
{
  return false;
}
